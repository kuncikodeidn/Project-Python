from PyQt5 import QtCore, QtGui, QtWidgets
from main1 import Ui_MainForm
from hasilfinal2 import Ui_Form as pekat_form # pekat
from hasilfinal3 import Ui_Form as padatan_form # padatan
from hasilfinal import Ui_Form as titerasi_form # titerasi
from logintubes import Ui_Form as login_form
from registertubes import Ui_Form as register_form


class Main1(QtWidgets.QMainWindow):
    def __init__(self):
        super(Main1, self).__init__()
        self.ui = Ui_MainForm()
        # self.ui.setupUi(self)
        self.setObjectName("Form")
        self.resize(400, 400)
        self.widget = QtWidgets.QWidget(self)
        self.widget.setGeometry(QtCore.QRect(0, 0, 400, 400))
        self.widget.setObjectName("widget")
        self.stack = QtWidgets.QStackedWidget()
        self.setCentralWidget(self.stack)

        # Login page
        self.login_page = QtWidgets.QWidget()
        self.login_ui = login_form()
        self.login_ui.setupUi(self.login_page, self.stack)
        self.stack.addWidget(self.login_page)
        
        # Register page
        self.register_page = QtWidgets.QWidget()
        self.register_ui = register_form()
        self.register_ui.setupUi(self.register_page, self.stack)
        self.stack.addWidget(self.register_page)


        # Main page
        self.main_page = QtWidgets.QWidget()
        self.ui.setupUi(self.main_page)
        self.stack.addWidget(self.main_page)

        # Page for Padatan
        self.padatan_page = QtWidgets.QWidget()
        self.padatan_ui = pekat_form()
        self.padatan_ui.setupUi(self.padatan_page, self.stack)
        self.stack.addWidget(self.padatan_page)

        # Page for Pekat
        self.pekat_page = QtWidgets.QWidget()
        self.pekat_ui = padatan_form()
        self.pekat_ui.setupUi(self.pekat_page, self.stack)
        self.stack.addWidget(self.pekat_page)

        # Page for Titrasi
        self.titrasi_page = QtWidgets.QWidget()
        self.titrasi_ui = titerasi_form()
        self.titrasi_ui.setupUi(self.titrasi_page, self.stack)
        self.stack.addWidget(self.titrasi_page)

        self.ui.stack = self.stack

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    main_window = Main1()
    main_window.show()
    sys.exit(app.exec_())
