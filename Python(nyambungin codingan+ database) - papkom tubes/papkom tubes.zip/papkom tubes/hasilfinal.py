from PyQt5 import QtCore, QtGui, QtWidgets
import halaman_7_rc

class Ui_Form(object):
    def setupUi(self, Form, stack):
        self.stack = stack
        Form.setObjectName("Form")
        Form.resize(400, 400)
        self.widget = QtWidgets.QWidget(Form)
        self.widget.setGeometry(QtCore.QRect(0, 0, 401, 401))
        self.widget.setObjectName("widget")
        
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(0, 0, 400, 400))
        self.label.setStyleSheet("border-image: url(:/background/Design.jpg);")
        self.label.setText("")
        self.label.setObjectName("label")
        
        self.label_5 = QtWidgets.QLabel(self.widget)
        self.label_5.setGeometry(QtCore.QRect(80, 10, 231, 41))
        font = QtGui.QFont()
        font.setFamily("Arial Black")
        font.setBold(True)
        font.setWeight(75)
        self.label_5.setFont(font)
        self.label_5.setStyleSheet("border-radius:20px;\n"
                                   "background-color: rgb(48, 184, 204);\n"
                                   "color: rgb(0, 0, 86);")
        self.label_5.setObjectName("label_5")
        
        self.label_9 = QtWidgets.QLabel(self.widget)
        self.label_9.setGeometry(QtCore.QRect(110, 320, 191, 41))
        self.label_9.setStyleSheet("border-radius:20px;\n"
                                   "background-color: rgb(134, 182, 241);\n"
                                   "")
        self.label_9.setText("")
        self.label_9.setObjectName("label_9")
        
        self.label_10 = QtWidgets.QLabel(self.widget)
        self.label_10.setGeometry(QtCore.QRect(10, 60, 211, 16))
        font = QtGui.QFont()
        font.setPointSize(6)
        font.setBold(True)
        font.setWeight(75)
        self.label_10.setFont(font)
        self.label_10.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_10.setObjectName("label_10")
        
        self.label_11 = QtWidgets.QLabel(self.widget)
        self.label_11.setGeometry(QtCore.QRect(200, 60, 211, 16))
        font = QtGui.QFont()
        font.setPointSize(6)
        font.setBold(True)
        font.setWeight(75)
        self.label_11.setFont(font)
        self.label_11.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_11.setObjectName("label_11")
        
        self.label_12 = QtWidgets.QLabel(self.widget)
        self.label_12.setGeometry(QtCore.QRect(20, 130, 211, 16))
        font = QtGui.QFont()
        font.setPointSize(6)
        font.setBold(True)
        font.setWeight(75)
        self.label_12.setFont(font)
        self.label_12.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_12.setObjectName("label_12")
        
        self.label_13 = QtWidgets.QLabel(self.widget)
        self.label_13.setGeometry(QtCore.QRect(210, 130, 211, 16))
        font = QtGui.QFont()
        font.setPointSize(6)
        font.setBold(True)
        font.setWeight(75)
        self.label_13.setFont(font)
        self.label_13.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_13.setObjectName("label_13")
        
        self.label_8 = QtWidgets.QLabel(self.widget)
        self.label_8.setGeometry(QtCore.QRect(120, 220, 171, 41))
        self.label_8.setStyleSheet("border-radius:20px;\n"
                                   "background-color: rgb(255, 255, 255);")
        self.label_8.setText("")
        self.label_8.setObjectName("label_8")
        
        self.label_14 = QtWidgets.QLabel(self.widget)
        self.label_14.setGeometry(QtCore.QRect(110, 200, 211, 16))
        font = QtGui.QFont()
        font.setPointSize(6)
        font.setBold(True)
        font.setWeight(75)
        self.label_14.setFont(font)
        self.label_14.setStyleSheet("color: rgb(255, 255, 255);")
        self.label_14.setObjectName("label_14")
        
        self.lineEdit_2 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_2.setGeometry(QtCore.QRect(30, 80, 151, 41))
        self.lineEdit_2.setStyleSheet("border-radius:20px;\n"
                                      "background-color: rgb(255, 255, 255);")
        self.lineEdit_2.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_2.setObjectName("lineEdit_2")
        
        self.lineEdit_4 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_4.setGeometry(QtCore.QRect(220, 80, 151, 41))
        self.lineEdit_4.setStyleSheet("border-radius:20px;\n"
                                      "background-color: rgb(255, 255, 255);")
        self.lineEdit_4.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_4.setObjectName("lineEdit_4")
        
        self.lineEdit_3 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_3.setGeometry(QtCore.QRect(30, 150, 151, 41))
        self.lineEdit_3.setStyleSheet("border-radius:20px;\n"
                                      "background-color: rgb(255, 255, 255);")
        self.lineEdit_3.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_3.setObjectName("lineEdit_3")
        
        self.lineEdit_5 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_5.setGeometry(QtCore.QRect(220, 150, 151, 41))
        self.lineEdit_5.setStyleSheet("border-radius:20px;\n"
                                      "background-color: rgb(255, 255, 255);")
        self.lineEdit_5.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_5.setObjectName("lineEdit_5")
        
        self.pushButton_2 = QtWidgets.QPushButton(self.widget)
        self.pushButton_2.setGeometry(QtCore.QRect(90, 270, 231, 41))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(14)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet("QPushButton#pushButton_2{\n"
                                        "    background-color: rgb(255, 255, 255);\n"
                                        "    font: 14pt \"Mongolian Baiti\";\n"
                                        "    color: rgb(255, 255, 255);\n"
                                        "    background-color: rgb(43, 32, 132);\n"
                                        "    border-radius:20px;\n"
                                        "}\n"
                                        "QPushButton#pushButton_2:hover{\n"
                                        "    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85,81, 84, 226))}\n"
                                        "\n"
                                        "QPushButton#pushButton_2:pressed{\n"
                                        "    padding-left:5px;\n"
                                        "    padding-top:5px;\n"
                                        "    background-color:rgba(150, 123, 111, 255);}")
        self.pushButton_2.setObjectName("pushButton_2")
        
        self.pushButton = QtWidgets.QPushButton(self.widget)
        self.pushButton.setGeometry(QtCore.QRect(310, 350, 81, 41))
        font = QtGui.QFont()
        font.setFamily("Mongolian Baiti")
        font.setPointSize(8)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet("QPushButton#pushButton{\n"
                                      "    background-color: rgb(170, 170, 255);\n"
                                      "    background-color: rgb(255, 255, 255);\n"
                                      "    font: 8pt \"Mongolian Baiti\";\n"
                                      "    \n"
                                      "    color: rgb(0, 0, 72);\n"
                                      "    \n"
                                      "    background-color: rgb(221, 221, 221);\n"
                                      "    border-radius:20px;\n"
                                      "}\n"
                                      "QPushButton#pushButton:hover{\n"
                                      "    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop:1 rgba(85,81, 84, 226))}\n"
                                      "\n"
                                      "QPushButton#pushButton:pressed{\n"
                                      "    padding-left:5px;\n"
                                      "    padding-top:5px;\n"
                                      "    background-color:rgba(150, 123, 111, 255);}")
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        self.pushButton.clicked.connect(self.to_main)

    def to_main(self):
        # Logic to go back to main1.py
        self.stack.setCurrentIndex(2)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_5.setText(_translate("Form", "                       Titrasi "))
        self.label_10.setText(_translate("Form", "     Masukkan Nilai Molaritas asam"))
        self.label_11.setText(_translate("Form", "     Masukkan Nilai Molaritas Basa"))
        self.label_12.setText(_translate("Form", "    Masukkan Nilai Volume Asam"))
        self.label_13.setText(_translate("Form", "    Masukkan Nilai Volume Basa"))
        self.label_14.setText(_translate("Form", "      Masukkan Nilai Fp"))
        self.lineEdit_2.setPlaceholderText(_translate("Form", "M"))
        self.lineEdit_4.setPlaceholderText(_translate("Form", "M"))
        self.lineEdit_3.setPlaceholderText(_translate("Form", "mL"))
        self.lineEdit_5.setPlaceholderText(_translate("Form", "mL"))
        self.pushButton_2.setText(_translate("Form", "HASIL"))
        self.pushButton.setText(_translate("Form", " KEMBALI"))

if __name__ == "__main__":
    global Form
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    stack = QtWidgets.QStackedWidget()
    ui = Ui_Form()
    ui.setupUi(Form, stack)
    Form.show()
    sys.exit(app.exec_())
