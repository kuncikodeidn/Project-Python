import mysql.connector

db_connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="papkom_tubes"
)



def register(username, password):
    cursor = db_connection.cursor()
    try:
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            message = "Username already taken. Please choose a different username."
            print(message)
        else:
            sql = "INSERT INTO users (username, password) VALUES (%s, %s)"
            cursor.execute(sql, (username, password))
            db_connection.commit()  
            message = "User registered successfully!"
            print(message)     
        cursor.close()
        # db_connection.close()
        return message
    
    except mysql.connector.Error as err:
        message = "Error:", err
        print(message)
        return message


def login(username, password):  
    cursor = db_connection.cursor()
    sql = "SELECT * FROM users WHERE username = %s AND password = %s"
    cursor.execute(sql, (username, password))
    user = cursor.fetchone()  
    if user:
        message = "Login successful!"
        print(message)
    else:
        message = "Invalid username or password"
        print(message)
        
    cursor.close()
    # db_connection.close()
    
    return message


if __name__ == "__main__":
    register("user2", "123")
    
    # login("user1", "password123")

