from PyQt5 import QtCore, QtGui, QtWidgets
from database import login

class Ui_Form(object):
    def setupUi(self, Form, stack):
        self.stack = stack
        Form.setObjectName("Form")
        Form.resize(400, 400)
        self.widget = QtWidgets.QWidget(Form)
        self.widget.setGeometry(QtCore.QRect(0, 0, 400, 400))
        self.widget.setObjectName("widget")
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(0, 0, 210, 400))
        self.label.setStyleSheet("border-image: url(:/gambar/Design.png);\n"
"border-top-left-radius: 50px;")
        self.label.setText("")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 210, 400))
        self.label_2.setStyleSheet("background-color:rgba(0, 0, 0, 10);\n"
"border-image: url(:/gambar2/Design.png);")
        self.label_2.setText("")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.widget)
        self.label_3.setGeometry(QtCore.QRect(200, 0, 200, 400))
        self.label_3.setStyleSheet("background-color:rgba(255,255,255,255);\n"
"")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.label_6 = QtWidgets.QLabel(self.widget)
        self.label_6.setGeometry(QtCore.QRect(270, 50, 70, 30))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.label_6.setFont(font)
        self.label_6.setStyleSheet("color:rgba(0,0,0,200);\n"
"")
        self.label_6.setObjectName("label_6")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_3.setGeometry(QtCore.QRect(230, 120, 150, 30))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_3.setFont(font)
        self.lineEdit_3.setStyleSheet("background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 200);\n"
"color:rgba(0, 0, 0, 240);\n"
"padding-bottom:7px;\n"
"")
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.widget)
        self.lineEdit_4.setGeometry(QtCore.QRect(230, 170, 150, 30))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.lineEdit_4.setFont(font)
        self.lineEdit_4.setStyleSheet("background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom: 2px solid rgba(46, 82, 101, 200);\n"
"color:rgba(0, 0, 0, 240);\n"
"padding-bottom:7px;\n"
"")
        self.lineEdit_4.setText("")
        self.lineEdit_4.setEchoMode(QtWidgets.QLineEdit.Password)
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.pushButton_3 = QtWidgets.QPushButton(self.widget)
        self.pushButton_3.setGeometry(QtCore.QRect(255, 230, 100, 25))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet("QPushButton#pushButton_3{\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop: 1 rgba(85, 98, 112, 226));\n"
"    color:rgba(225, 225, 225, 210);\n"
"    border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_3:hover{\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop: 1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_3:pressed{\n"
"    padding-left:5px;\n"
"    padding-top:5px;\n"
"    background-color: rgba(150, 123, 111, 225);\n"
"}")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.widget)
        self.pushButton_4.setGeometry(QtCore.QRect(255, 290, 100, 25))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet("QPushButton#pushButton_4{\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(11, 131, 120, 219), stop: 1 rgba(85, 98, 112, 226));\n"
"    color:rgba(225, 225, 225, 210);\n"
"    border-radius:5px;\n"
"}\n"
"\n"
"QPushButton#pushButton_4:hover{\n"
"    background-color: qlineargradient(spread:pad, x1:0, y1:0.505682, x2:1, y2:0.477, stop:0 rgba(150, 123, 111, 219), stop: 1 rgba(85, 81, 84, 226));\n"
"}\n"
"\n"
"QPushButton#pushButton_4:pressed{\n"
"    padding-left:5px;\n"
"    padding-top:5px;\n"
"    background-color: rgba(150, 123, 111, 225);\n"
"}")
        self.pushButton_4.setObjectName("pushButton_4")
        self.label_4 = QtWidgets.QLabel(self.widget)
        self.label_4.setGeometry(QtCore.QRect(258, 270, 100, 10))
        self.label_4.setObjectName("label_4")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

        self.pushButton_4.clicked.connect(self.register)
        self.pushButton_3.clicked.connect(self.login)

    def register(self):
        self.stack.setCurrentIndex(1)
        # self.widget.window().close()

    def login(self):
        username = self.lineEdit_3.text()  # Retrieve the username from the input field
        password = self.lineEdit_4.text()  # Retrieve the password from the input field
        message = login(username, password)  # Pass the values to the login function
        if message == "Login successful!":
            self.stack.setCurrentIndex(2)
        else:
            QtWidgets.QMessageBox.warning(None, "Login Failed", message)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_6.setText(_translate("Form", "Log In"))
        self.lineEdit_3.setPlaceholderText(_translate("Form", "User Name"))
        self.lineEdit_4.setPlaceholderText(_translate("Form", "Password"))
        self.pushButton_3.setText(_translate("Form", "L o g  I n"))
        self.pushButton_4.setText(_translate("Form", "R e g i s t e r"))
        self.label_4.setText(_translate("Form", "Don\'t have an account yet?"))
import latar


if __name__ == "__main__":
    import sys 
    app = QtWidgets.QApplication(sys.argv)
    Form = QtWidgets.QWidget()
    stack = QtWidgets.QStackedWidget()
    ui = Ui_Form()
    ui.setupUi(Form, stack)
    Form.show()
    sys.exit(app.exec_())
